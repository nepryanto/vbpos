﻿Imports System.Data.SqlClient

Public Class Form2
    Sub tampil()
        Call KONEKSI()
        DA = New SqlDataAdapter("select * from tblbarang", CONN)
        DS = New DataSet
        DA.Fill(DS)
        dgv.DataSource = DS.Tables(0)
        dgv.ReadOnly = True
    End Sub

    Sub satuan()
        Call KONEKSI()
        CMD = New SqlCommand("select distinct SATUAN FROM TblBarang", CONN)


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form1.Show()
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call tampil()

    End Sub
End Class