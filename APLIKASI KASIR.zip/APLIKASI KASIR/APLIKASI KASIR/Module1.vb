﻿Imports System.Data.SqlClient

Module Module1
    Public CONN As SqlConnection
    'data satu tabel
    Public DA As SqlDataAdapter
    Public DS As New DataSet
    'data satuan
    Public CMD As New SqlCommand
    Public DR As SqlDataReader

    Public STR As String

    Sub KONEKSI()
        STR = "DATA SOURCE=DESKTOP-98GQNQ2;INITIAL CATALOG=KASIR_POS;INTEGRATED SECURITY=TRUE"
        CONN = New SqlConnection(STR)
        If CONN.State = ConnectionState.Closed Then
            CONN.Open()
        End If
    End Sub

End Module
